package stadium;

public class StadiumDTO {
	String std_Id;
	String std_Name;
	String link;
	String coordinate_X;
	String coordinate_Y;
	String p_Number;
	String img_Url;
	String mng_Name;
	String view_Details;
	
	
	public String getStd_Id() {
		return std_Id;
	}
	public void setStd_Id(String std_Id) {
		this.std_Id = std_Id;
	}
	public String getStd_Name() {
		return std_Name;
	}
	public void setStd_Name(String std_Name) {
		this.std_Name = std_Name;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getCoordinate_X() {
		return coordinate_X;
	}
	public void setCoordinate_X(String coordinate_X) {
		this.coordinate_X = coordinate_X;
	}
	public String getCoordinate_Y() {
		return coordinate_Y;
	}
	public void setCoordinate_Y(String coordinate_Y) {
		this.coordinate_Y = coordinate_Y;
	}
	public String getP_Number() {
		return p_Number;
	}
	public void setP_Number(String p_Number) {
		this.p_Number = p_Number;
	}
	public String getImg_Url() {
		return img_Url;
	}
	public void setImg_Url(String img_Url) {
		this.img_Url = img_Url;
	}
	public String getMng_Name() {
		return mng_Name;
	}
	public void setMng_Name(String mng_Name) {
		this.mng_Name = mng_Name;
	}
	public String getView_Details() {
		return view_Details;
	}
	public void setView_Details(String view_Details) {
		this.view_Details = view_Details;
	}
	
	
}
